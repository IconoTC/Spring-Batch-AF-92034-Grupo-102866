package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo05SpringBatchMultiResourcesItemReaderApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo05SpringBatchMultiResourcesItemReaderApplication.class, args);
	}

}
