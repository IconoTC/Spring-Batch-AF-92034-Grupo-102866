package es.indra.config;

import java.util.Arrays;
import java.util.List;

import org.springframework.batch.core.job.Job;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.Step;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

import es.indra.business.CustomReader;
import es.indra.business.CustomWriter;
import es.indra.business.ProcesadorProductos;
import es.indra.models.Producto;

@Configuration
public class BatchConfiguration {
	
	@Autowired
	private JobRepository jobRepository;
	
	@Autowired
	private PlatformTransactionManager txManager;
	
	
	@Bean
	public Job job() {
		return new JobBuilder("job1", jobRepository)
				.flow(step())
				.end()
				.build();
	}
	
	@Bean
	public Step step() {
		return new StepBuilder("step1", jobRepository)
				.<Producto,Producto>chunk(1, txManager)   // nº de registros que manejamos en cada bloque
				.reader(itemReader())
				.processor(itemProcesor())
				.writer(itemWriter())
				.taskExecutor(taskExecutor())
				.build();
	}
	
	// Este bean hace que trabajemos con 3 hilos
	@Bean
	public TaskExecutor taskExecutor() {
		SimpleAsyncTaskExecutor simpleAsyncTaskExecutor = new SimpleAsyncTaskExecutor("task");
		simpleAsyncTaskExecutor.setConcurrencyLimit(3);
		return simpleAsyncTaskExecutor;
	}
	
	
	// ItemReader para leer los productos del data.csv
	@Bean
	public CustomReader itemReader(){
		List<Producto> lista = Arrays.asList(
				new Producto(1,"Portatil",1400),
				new Producto(2,"Raton",45),
				new Producto(3,"Pantalla",156),
				new Producto(4,"Disco externo",120),
				new Producto(5,"Altavoces",95));
		return new CustomReader(lista);
	}
	
	
	// ItemProcesor procesa cada producto leido
	@Bean
	public ProcesadorProductos itemProcesor() {
		return new ProcesadorProductos();
	}
	
	// ItemWriter escribe los productos recibidos del ItemProcesor en la BBDD
	@Bean
	public CustomWriter itemWriter(){
		return new CustomWriter();
	}

}










