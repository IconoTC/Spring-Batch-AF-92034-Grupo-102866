package es.indra.business;

import java.util.Iterator;
import java.util.List;

import org.jspecify.annotations.Nullable;
import org.springframework.batch.infrastructure.item.ItemReader;

import es.indra.models.Producto;

public class CustomReader implements ItemReader<Producto> {

	private Iterator<Producto> iterator;

	public CustomReader(List<Producto> lista) {
		super();
		this.iterator = lista.iterator();
	}

	@Override
	public @Nullable Producto read() throws Exception {
		System.out.println("Leyendo productos ......");
		
		if (iterator.hasNext()) {
			return iterator.next();
		}

		// Cuando ya no hay mas productos, retorna un null
		// para dar por finalizado el CustomReader
		return null;
	}

}
