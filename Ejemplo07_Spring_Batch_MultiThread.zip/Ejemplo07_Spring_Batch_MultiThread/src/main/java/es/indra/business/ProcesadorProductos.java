package es.indra.business;

import org.jspecify.annotations.Nullable;
import org.springframework.batch.infrastructure.item.ItemProcessor;

import es.indra.models.Producto;

public class ProcesadorProductos implements ItemProcessor<Producto, Producto>{

	@Override
	public @Nullable Producto process(Producto item) throws Exception {
		
		// Aplicamos un 10% de dto en el precio del producto
		// La descripcion la ponemos en mayuscula
		
		double nuevoPrecio = item.getPrecio() * 0.9;
		String nuevaDescripcion = item.getDescripcion().toUpperCase();
		
		Producto nuevo = new Producto(item.getId(), nuevaDescripcion, nuevoPrecio);
		
		System.out.println("Producto entrada: " + item);
		System.out.println("Producto salida: " + nuevo);
		
		return nuevo;
	}

}
