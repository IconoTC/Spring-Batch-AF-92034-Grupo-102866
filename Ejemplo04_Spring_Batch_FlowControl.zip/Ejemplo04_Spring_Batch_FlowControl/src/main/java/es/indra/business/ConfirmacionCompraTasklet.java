package es.indra.business;

import org.jspecify.annotations.Nullable;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.StepContribution;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.infrastructure.repeat.RepeatStatus;
import org.springframework.stereotype.Service;

@Service
public class ConfirmacionCompraTasklet implements Tasklet {

	@Override
	public @Nullable RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		
		if (false) {
			contribution.setExitStatus(ExitStatus.FAILED);
			System.out.println("Ha ocurrido un error en confirmacion de compra");
		} else {
			contribution.setExitStatus(ExitStatus.COMPLETED);
		}
		
		System.out.println("Ejecutando el proceso de Confirmacion de compra con tasklet");
		return RepeatStatus.FINISHED;
	}

}
