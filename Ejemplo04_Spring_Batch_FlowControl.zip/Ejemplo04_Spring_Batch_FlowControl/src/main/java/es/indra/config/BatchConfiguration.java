package es.indra.config;

import org.springframework.batch.core.job.Job;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.Step;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import es.indra.business.ConfirmacionCompraTasklet;
import es.indra.business.ErrorTasklet;
import es.indra.business.LoginTasklet;
import es.indra.business.PagoTasklet;

@Configuration
public class BatchConfiguration {
	
	@Autowired
	private JobRepository jobRepository;
	
	@Autowired
	private LoginTasklet loginTasklet;
	
	@Autowired
	private PagoTasklet pagoTasklet;
	
	@Autowired
	private ConfirmacionCompraTasklet confirmacionCompraTasklet;
	
	@Autowired
	private ErrorTasklet errorTasklet;
	
	// Crear el job secuencial
//	@Bean
//	public Job jobSecuencial() {
//		return new JobBuilder("jobSecuencial", jobRepository)
//				.start(stepLogin())
//				.next(stepConfirmacionCompra())
//				.next(stepPago())
//				.build();
//	}
	
	// Crear el job condicional
//	@Bean
//	public Job jobCondicinal() {
//		return new JobBuilder("jobCondicional", jobRepository)
//				.start(stepLogin())
//					.on("FAILED").end()
//					.on("*").to(stepConfirmacionCompra())
//				.from(stepConfirmacionCompra())
//					.on("FAILED").end()
//					.on("*").to(stepPago())
//				.from(stepPago())
//					.on("FAILED").end()
//				.end()
//				.build();
//	}
	
	@Bean
	public Job jobCondicinalConError() {
		return new JobBuilder("jobCondicinalConError", jobRepository)
				.start(stepLogin())
					.on("FAILED").to(stepError())
				.from(stepLogin())
					.on("*").to(stepConfirmacionCompra())
				.from(stepConfirmacionCompra())
					.on("FAILED").to(stepError())
				.from(stepConfirmacionCompra())
					.on("*").to(stepPago())
				.from(stepPago())
					.on("FAILED").to(stepError())
				.from(stepPago())
					.on("*").end()
				.from(stepError())
					.on("*").end()
				.end()
				.build();
	}
	
	
	@Bean
	public Step stepLogin() {
		return new StepBuilder("stepLogin", jobRepository)
				.tasklet(loginTasklet)
				.build();
	}
	
	@Bean
	public Step stepPago() {
		return new StepBuilder("stepPago", jobRepository)
				.tasklet(pagoTasklet)
				.build();
	}
	
	@Bean
	public Step stepConfirmacionCompra() {
		return new StepBuilder("stepConfirmacionCompra", jobRepository)
				.tasklet(confirmacionCompraTasklet)
				.build();
	}
	
	@Bean
	public Step stepError() {
		return new StepBuilder("stepError", jobRepository)
				.tasklet(errorTasklet)
				.build();
	}

}
