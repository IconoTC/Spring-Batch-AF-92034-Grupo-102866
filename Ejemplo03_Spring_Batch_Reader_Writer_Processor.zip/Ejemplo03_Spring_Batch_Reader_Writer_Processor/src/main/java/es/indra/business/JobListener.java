package es.indra.business;

import org.springframework.batch.core.job.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;

import es.indra.persistence.ProductosDAO;

public class JobListener implements JobExecutionListener{
	
	@Autowired
	private ProductosDAO dao;

	@Override
	public void beforeJob(JobExecution jobExecution) {
		System.out.println("-------- Iniciando el job");
	}

	@Override
	public void afterJob(JobExecution jobExecution) {
		System.out.println("-------- Finalizado el job");
		dao.findAll()
			.stream()
			.forEach(System.out::println);
	}
	
	

}
