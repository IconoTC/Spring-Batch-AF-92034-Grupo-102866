package es.indra.util;


import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import es.indra.models.Producto;

@Service
public class ProductoRecoverService {
	
	private final AtomicInteger contador = new AtomicInteger();
	
	@Retryable(value = RuntimeException.class, maxAttempts = 3, backoff = @Backoff(delay = 2000))
	public Producto validate(Producto producto) {
		
		int intento = contador.incrementAndGet();
		
		System.out.println("Intento " + intento + " para producto " + producto.getDescripcion());
		
		if (producto.getId() == 3) {
			throw new RuntimeException("Ha ocurrido un error");
		}
		
		return producto;
		
	}
	
	@Recover
	public String recover(RuntimeException ex, Producto producto) {
		System.out.println("RECOVER ejecutando para " + producto.getDescripcion());
		
		return "VALIDACION_FALLIDA";
	}

}
