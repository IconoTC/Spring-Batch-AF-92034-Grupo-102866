package es.indra.business;

import org.springframework.batch.infrastructure.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import es.indra.models.Producto;
import es.indra.util.ProductoRecoverService;

public class ProcesadorProductos implements ItemProcessor<Producto, Producto>{
	
	@Autowired
	private ProductoRecoverService service;

	@Override
	public Producto process(Producto item) throws Exception {
		
		// Aplicamos un 10% de dto en el precio del producto
		// La descripcion la ponemos en mayuscula
		
		double nuevoPrecio = item.getPrecio() * 0.9;
		String nuevaDescripcion = item.getDescripcion().toUpperCase();
		
		Producto nuevo = new Producto(item.getId(), nuevaDescripcion, nuevoPrecio);
		
		//System.out.println("Producto entrada: " + item);
		//System.out.println("Producto salida: " + nuevo);
		
//		if (item.getId() == 3) {
//			throw new RuntimeException("Ha ocurrido un error");
//		}
		
		return service.validate(nuevo);
	}

}
