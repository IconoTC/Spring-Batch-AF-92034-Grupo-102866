package es.indra.config;

import java.util.Arrays;
import java.util.List;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.job.Job;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.Step;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.transaction.PlatformTransactionManager;

import es.indra.business.CustomReader;
import es.indra.business.CustomWriter;
import es.indra.business.ProcesadorProductos;
import es.indra.models.Producto;

@Configuration
@EnableBatchProcessing
@EnableRetry
public class BatchConfiguration {
	
	@Autowired
	private JobRepository jobRepository;
	
	@Autowired
	private PlatformTransactionManager txManager;
	
	
	@Bean
	public Job job() {
		return new JobBuilder("job1", jobRepository)
				.flow(step())
				.end()
				.build();
	}
	
	@Bean
	public Step step() {
		return new StepBuilder("step1", jobRepository)
				.<Producto,Producto>chunk(1)   
				.reader(itemReader())
				.processor(itemProcesor())
				.writer(itemWriter())
				.build();
	}	

	@Bean
	public CustomReader itemReader(){
		List<Producto> lista = Arrays.asList(
				new Producto("Portatil",1400),
				new Producto("Raton",45),
				new Producto("Pantalla",156),
				new Producto("Disco externo",120),
				new Producto("Altavoces",95));
		return new CustomReader(lista);
	}	
	
	@Bean
	public ProcesadorProductos itemProcesor() {
		return new ProcesadorProductos();
	}
	
	@Bean
	public CustomWriter itemWriter(){
		return new CustomWriter();
	}

}










