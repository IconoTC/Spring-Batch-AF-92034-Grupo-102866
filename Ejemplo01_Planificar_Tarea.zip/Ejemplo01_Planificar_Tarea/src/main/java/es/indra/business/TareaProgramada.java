package es.indra.business;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

/*
 * En Spring toda clase anotada con una de estas 4 anotaciones, se reconoce como un bean de Spring:
 * 		@Repository; repositorio de datos, DAO, LDAP, ERP
 * 		@Service; logica de negocio, servicios
 * 		@Controller; controladores de Spring MVC
 *      @Component; cuando la clase no es ninguna de las anteriores
 * */

@Service    // Quiero un bean de esta clase
public class TareaProgramada {
	
	// Queremos que se ejecute cada 3 segundos
	@Scheduled(fixedRate = 3000)
	public void contenido() {
		System.out.println("Bienvenidos al curso de Spring Batch");
	}

}
