package es.indra.listener;

import org.springframework.batch.core.listener.ItemWriteListener;
import org.springframework.batch.infrastructure.item.Chunk;

import es.indra.models.Producto;

public class CustomWriterListener implements ItemWriteListener<Producto>{

	@Override
	public void beforeWrite(Chunk<? extends Producto> items) {
		System.out.println(" -------- Iniciando la escritura " + items);
	}

	@Override
	public void afterWrite(Chunk<? extends Producto> items) {
		System.out.println(" -------- Finalizando la escritura " + items);
	}

	@Override
	public void onWriteError(Exception exception, Chunk<? extends Producto> items) {
		System.out.println("Error de escritura: " + exception.getMessage());
	}
	
	

}
