package es.indra.listener;

import org.jspecify.annotations.Nullable;
import org.springframework.batch.core.listener.ItemProcessListener;

import es.indra.models.Producto;

public class CustomProcessorListener implements ItemProcessListener<Producto, Producto>{

	@Override
	public void beforeProcess(Producto item) {
		System.out.println(" ------ Iniciando el procesador de productos " + item);
	}

	@Override
	public void afterProcess(Producto entrada, @Nullable Producto salida) {
		System.out.println(" ------ Finalizado el procesador de productos");
		//System.out.println("Producto entrada: " + entrada);
		//System.out.println("Producto salida: " + salida);
	}

	@Override
	public void onProcessError(Producto item, Exception e) {
		System.out.println("Ha ocurrido un error con el producto " + item);
		System.out.println(e.getMessage());
	}

	
}
