package es.indra.listener;

import org.springframework.batch.core.job.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListener;

public class JobListener implements JobExecutionListener{

	@Override
	public void beforeJob(JobExecution jobExecution) {
		System.out.println("-------- Iniciando el job");
	}

	@Override
	public void afterJob(JobExecution jobExecution) {
		System.out.println("-------- Finalizando el job");
	}
	
	

}
