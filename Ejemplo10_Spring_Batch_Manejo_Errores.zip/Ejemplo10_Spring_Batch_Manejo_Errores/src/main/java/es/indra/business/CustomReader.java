package es.indra.business;

import java.util.Iterator;
import java.util.List;

import org.jspecify.annotations.Nullable;
import org.springframework.batch.infrastructure.item.ItemReader;

import es.indra.models.Producto;

public class CustomReader implements ItemReader<Producto> {

	private Iterator<Producto> iterator;
	static int contador = 1;

	public CustomReader(List<Producto> lista) {
		super();
		this.iterator = lista.iterator();
	}

	@Override
	public @Nullable Producto read() throws Exception {
		System.out.println("Leyendo productos ......");
		
		if (iterator.hasNext()) {
			Producto producto = iterator.next();
//			if (contador == 3) {
//				throw new RuntimeException("Error con el producto de codigo 3");
//			}
			producto.setId(contador);
			contador++;
			return producto;
		}
		
		// Cuando ya no hay mas productos, retorna un null
		// para dar por finalizado el CustomReader
		return null;
	}

}
