package es.indra.config;

import org.springframework.batch.core.job.Job;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.Step;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.infrastructure.item.file.MultiResourceItemReader;
import org.springframework.batch.infrastructure.item.file.builder.MultiResourceItemReaderBuilder;
import org.springframework.batch.infrastructure.item.xml.StaxEventItemReader;
import org.springframework.batch.infrastructure.item.xml.StaxEventItemWriter;
import org.springframework.batch.infrastructure.item.xml.builder.StaxEventItemReaderBuilder;
import org.springframework.batch.infrastructure.item.xml.builder.StaxEventItemWriterBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import es.indra.models.Producto;

@Configuration
public class BatchConfiguration {
	
	@Autowired
	private JobRepository jobRepository;
	
	@Bean
	public Job job() {
		return new JobBuilder("job1", jobRepository)
				.start(step())
				.build();
	}
	
	@Bean
	public Step step() {
		return new StepBuilder("step1", jobRepository)
				.<Producto, Producto>chunk(2)
				.reader(multiResourceItemReader())
				.writer(itemWriter())
				.build();
	}
	
//	@Bean
//	public MultiResourceItemReader<Producto> multiResourceItemReader(
//			@Value("file:src/main/resources/input/data*.csv") Resource[] resources){
	
	
    // Otra forma de no recibir resources como parametro del metodo
	@Bean
	public MultiResourceItemReader<Producto> multiResourceItemReader(){
		Resource[] resources = {
			new ClassPathResource("input/productos1.xml"),
			new ClassPathResource("input/productos2.xml"),
			new ClassPathResource("input/productos3.xml")
		};
		
		return new MultiResourceItemReaderBuilder<Producto>()
				.name("multiResourceItemReader")
				.resources(resources)
				.delegate(itemReader())   // cada datax.csv se lo pasamos al itemReader
				.build();
	}
	
	@Bean
	public StaxEventItemReader<Producto> itemReader(){
		StaxEventItemReader<Producto> reader = new StaxEventItemReader(marshaller());
		reader.setFragmentRootElementName("producto");
		//reader.setUnmarshaller(marshaller());
		return reader;
	}
	
	/*
	 * xml -> Objeto Java    (Unmarshall)
	 * Objeto Java -> xml    (Marshall)
	 * */
	@Bean
	public Jaxb2Marshaller marshaller() {
		// Este bean se encarga de hacer las operaciones Marshall y Unmarshall
		// Por cada <producto> que leo del .xml queremos que lo retorne como Producto.class y viceversa
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller.setClassesToBeBound(Producto.class);
		return marshaller;
	}
	
	@Bean
	public StaxEventItemWriter<Producto> itemWriter(){
		StaxEventItemWriter<Producto> writer = new StaxEventItemWriter(marshaller());
		// No funciona con ClassPathResource
		writer.setResource(new FileSystemResource("src/main/resources/output/resultado_productos.xml"));
		//writer.setMarshaller(marshaller());
		writer.setRootTagName("productos");
		return writer;
	}

}














