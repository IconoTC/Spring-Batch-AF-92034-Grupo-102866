package es.indra.config;

import org.springframework.batch.core.job.Job;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.Step;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.infrastructure.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import es.indra.business.MyTasklet;

@Configuration
public class BatchConfiguration {
	
	@Autowired   // DI - Inyectar un bean de tipo JobRepository
	private JobRepository jobRepository;
	
	@Autowired   // DI - Inyectar un bean de tipo  MyTasklet
	private MyTasklet myTasklet;
	
	
	@Bean
	public Job job() {
		return new JobBuilder("job1", jobRepository)
				.start(step())
				.build();
	}
	
	@Bean   // Convierto el objeto Java que retorna el metodo en un bean de Spring
	public Step step() {
		
		return new StepBuilder("step1", jobRepository)
				.tasklet(myTasklet)
				.build();
		
		/*
		return new StepBuilder("step1", jobRepository)
				.tasklet( (contribution, chunkContext) -> {
					System.out.println("Ejecutando el tasklet con lambda");
					return RepeatStatus.FINISHED;
				})
				.build();
		*/
	}

}








