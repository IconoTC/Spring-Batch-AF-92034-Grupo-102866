package es.indra.business;

import java.util.Map;

import org.jspecify.annotations.Nullable;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.StepContribution;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.infrastructure.repeat.RepeatStatus;
import org.springframework.stereotype.Service;

// Un tasket se utiliza cuando el proceso a ejecutar con Spring Batch
// es tan sencillo que no necesita: ItemReader, ItemWriter, ItemProcessor

@Service
public class MyTasklet implements Tasklet{

	@Override
	public @Nullable RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		
		// Recuperar los parametros del job
		Map<String, Object> parametros = chunkContext.getStepContext().getJobParameters();
		
		System.out.println(parametros.get("prueba"));
		System.out.println(parametros.get("time"));
		
		System.out.println("Ejecutando el tasklet");
		return RepeatStatus.FINISHED;
	}

}
