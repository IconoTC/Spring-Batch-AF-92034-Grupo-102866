package es.indra;

import org.springframework.batch.core.job.Job;
import org.springframework.batch.core.job.JobExecution;
import org.springframework.batch.core.job.parameters.JobParameters;
import org.springframework.batch.core.job.parameters.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo02SpringBatchTaskletApplication implements CommandLineRunner{
	
	@Autowired
	private Job job;
	
	@Autowired
	private JobLauncher jobLauncher;

	// En los proyectos con Spring Boot el metodo main esta dedicado
	// exclusivamente a levantar el contexto de Spring
	public static void main(String[] args) {
		SpringApplication.run(Ejemplo02SpringBatchTaskletApplication.class, args);
	}

	// Este metodo siempre se ejecuta a continuacion del metodo main
	// Tengo la garantia de que se han creado los beans y estan en el contenedor
	@Override
	public void run(String... args) throws Exception {
		
		// Crear los parametros del Job
		JobParameters jobParameters = new JobParametersBuilder()
				.addString("prueba", "Esto es un parametro del job")
				.addLong("time", System.currentTimeMillis())
				.toJobParameters();
		
		// Asignamos los parametros al Job y lo lanzamos con JobLauncher
		JobExecution jobExecution = jobLauncher.run(job, jobParameters);
		
		// Mostrar la informacion de la ejecuccion del job
		System.out.println(jobExecution);
		System.out.println("Status: " + jobExecution.getStatus());
		System.out.println("Exit Status: " + jobExecution.getExitStatus());
		System.out.println("Hora inicio: " + jobExecution.getStartTime());
		System.out.println("Hora fin: " + jobExecution.getEndTime());
	}

}







